from .magic_cnki import MagicCNKI

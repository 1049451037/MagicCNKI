# MagicCNKI

CNKI search API. This is a brother project with [MagicBaidu](https://github.com/1049451037/MagicBaidu).

# Requirement

* Python 3

# Installation

```shell
pip install MagicCNKI
```

# Usage

See or run test.py

# High Level Usage

Advanced search methods can be explored from http://search.cnki.net/